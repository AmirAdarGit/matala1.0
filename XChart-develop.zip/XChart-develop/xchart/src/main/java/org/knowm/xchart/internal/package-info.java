/**
 * Classes in this package are internal and are not intended to be accessed directly. Therefore,
 * they are not included in the JavaDocs.
 */
package org.knowm.xchart.internal;
